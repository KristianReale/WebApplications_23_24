--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE webapp24_ristoranti;
--
-- Name: webapp24_ristoranti; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE webapp24_ristoranti WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE webapp24_ristoranti OWNER TO postgres;

\connect webapp24_ristoranti

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: piatto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.piatto (
    id bigint NOT NULL,
    nome character varying NOT NULL,
    prezzo double precision NOT NULL
);


ALTER TABLE public.piatto OWNER TO postgres;

--
-- Name: recensione; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recensione (
    id bigint NOT NULL,
    titolo character varying NOT NULL,
    testo character varying NOT NULL,
    numero_mipiace integer DEFAULT 0 NOT NULL,
    numero_nonmipiace integer DEFAULT 0 NOT NULL,
    ristorante integer NOT NULL,
    scritta_da character varying NOT NULL
);


ALTER TABLE public.recensione OWNER TO postgres;

--
-- Name: ristorante; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ristorante (
    id integer NOT NULL,
    nome character varying NOT NULL,
    descrizione character varying,
    ubicazione character varying NOT NULL
);


ALTER TABLE public.ristorante OWNER TO postgres;

--
-- Name: serve; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.serve (
    id bigint NOT NULL,
    piatto bigint NOT NULL,
    ristorante bigint NOT NULL
);


ALTER TABLE public.serve OWNER TO postgres;

--
-- Name: utente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utente (
    username character varying NOT NULL,
    password character varying NOT NULL,
    nome character varying NOT NULL,
    cognome character varying NOT NULL,
    data_nascita date NOT NULL,
    ruolo character varying NOT NULL
);


ALTER TABLE public.utente OWNER TO postgres;

--
-- Data for Name: piatto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.piatto (id, nome, prezzo) FROM stdin;
\.
COPY public.piatto (id, nome, prezzo) FROM '$$PATH$$/4794.dat';

--
-- Data for Name: recensione; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recensione (id, titolo, testo, numero_mipiace, numero_nonmipiace, ristorante, scritta_da) FROM stdin;
\.
COPY public.recensione (id, titolo, testo, numero_mipiace, numero_nonmipiace, ristorante, scritta_da) FROM '$$PATH$$/4795.dat';

--
-- Data for Name: ristorante; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ristorante (id, nome, descrizione, ubicazione) FROM stdin;
\.
COPY public.ristorante (id, nome, descrizione, ubicazione) FROM '$$PATH$$/4792.dat';

--
-- Data for Name: serve; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.serve (id, piatto, ristorante) FROM stdin;
\.
COPY public.serve (id, piatto, ristorante) FROM '$$PATH$$/4796.dat';

--
-- Data for Name: utente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utente (username, password, nome, cognome, data_nascita, ruolo) FROM stdin;
\.
COPY public.utente (username, password, nome, cognome, data_nascita, ruolo) FROM '$$PATH$$/4793.dat';

--
-- Name: piatto piatto_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.piatto
    ADD CONSTRAINT piatto_pk PRIMARY KEY (id);


--
-- Name: recensione recensione_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_pk PRIMARY KEY (id);


--
-- Name: ristorante ristorante_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ristorante
    ADD CONSTRAINT ristorante_pk PRIMARY KEY (id);


--
-- Name: serve serve_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serve
    ADD CONSTRAINT serve_pk PRIMARY KEY (id);


--
-- Name: utente utente_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utente
    ADD CONSTRAINT utente_pk PRIMARY KEY (username);


--
-- Name: recensione recensione_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT recensione_fk FOREIGN KEY (ristorante) REFERENCES public.ristorante(id);


--
-- Name: serve serve_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serve
    ADD CONSTRAINT serve_fk FOREIGN KEY (piatto) REFERENCES public.piatto(id);


--
-- Name: serve serve_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serve
    ADD CONSTRAINT serve_fk_1 FOREIGN KEY (ristorante) REFERENCES public.ristorante(id);


--
-- Name: recensione utente_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensione
    ADD CONSTRAINT utente_fk FOREIGN KEY (scritta_da) REFERENCES public.utente(username);


--
-- PostgreSQL database dump complete
--

